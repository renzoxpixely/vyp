<?php
require_once('../../../conexion.php');
require_once('locales.php');



$val   			= isset($_REQUEST['val'])? ($_REQUEST['val']) : ""; 
$country_ID             = isset($_REQUEST['country_ID'])? ($_REQUEST['country_ID']) : "";
$country		= isset($_REQUEST['country'])? ($_REQUEST['country']) : "";
$date1 			= isset($_REQUEST['date1'])? ($_REQUEST['date1']) : "";
$date2 			= isset($_REQUEST['date2'])? ($_REQUEST['date2']) : "";
$report			= isset($_REQUEST['report'])? ($_REQUEST['report']) : "";
$inicio 		= isset($_REQUEST['inicio'])? ($_REQUEST['inicio']) : "";
$pagina 		= isset($_REQUEST['pagina'])? ($_REQUEST['pagina']) : "";
$tot_pag 		= isset($_REQUEST['tot_pag'])? ($_REQUEST['tot_pag']) : "";
$registros              = isset($_REQUEST['registros'])? ($_REQUEST['registros']) : "";
$local 			= isset($_REQUEST['local'])? ($_REQUEST['local']) : "";
$SoloCompras            = isset($_REQUEST['SoloCompras']) ? ($_REQUEST['SoloCompras']) : "";


function convertir_a_numero($str)
{
	  $legalChars = "%[^0-9\-\. ]%";
	  $str=preg_replace($legalChars,"",$str);
	  return $str;
}
$date1 = $_POST['date1'];
$local = $_POST['local'];

$sql1="SELECT factor,qtypro,fraccion,sactual FROM kardex WHERE fecha = '2019/06/19' and and codpro = '$country_ID' and sucursal = '$local' ORDER BY fecha, codkard DESC LIMIT 1 ";
        $result1 = mysqli_query($conexion,$sql1);
        if (mysqli_num_rows($result1)){
        while ($row1 = mysqli_fetch_array($result1)){
        $factor1    = $row1['factor'];
        $qtypro1    = $row1['qtypro'];
        $fraccion1  = $row1['fraccion'];
        $sactual1   = $row1['sactual'];
        
        if ($qtypro <> "")
            {
                   
                    $descuenta  = $qtypro1 * $factor;
                    $re	        = $sactual1 - $descuenta;
            }
            if ($fraccion <> "")
            {
                    $cant2     = convertir_a_numero($fraccion);
                    $descuenta = $cant2;
                    $re	       = $sactual1 - $descuenta;
            }
        
        
        }
        }  





$sql="select codpro,sucursal from kardex where fecha between '2019/06/20' and '$date2' and codpro = '$country_ID' and sucursal = '$local' group by codpro,sucursal order by codpro";
$result = mysqli_query($conexion,$sql);
if (mysqli_num_rows($result)){
while ($row = mysqli_fetch_array($result)){
	$codpro     = $row['codpro'];
	$sucursal   = $row['sucursal'];
	$sql1="SELECT nomloc FROM xcompa where codloc = '$sucursal'";
	$result1 = mysqli_query($conexion,$sql1);
	if (mysqli_num_rows($result1)){
	while ($row1 = mysqli_fetch_array($result1)){
		$nomloc    = $row1['nomloc'];}}
	$tabla = locals($nomloc);
	$saldoactual = 0;
	$tipmov = 0;
	$tipdoc = 0;
	$qtypro = 0;
	$fraccion = 0;
	$factor = 0;
	$car    = 0;
	$sql1="select tipmov,tipdoc,qtypro,fraccion,factor,sactual from kardex where codpro = '$codpro' and sucursal = '$sucursal' and fecha >= '$date1' order by fecha,codkard";
	$result1 = mysqli_query($conexion,$sql1);
	if (mysqli_num_rows($result1)){
	while ($row1 = mysqli_fetch_array($result1)){
			$tipmov    = $row1['tipmov'];
			$tipdoc    = $row1['tipdoc'];
			$qtypro    = $row1['qtypro'];
			$fraccion  = $row1['fraccion'];
			$factor    = $row1['factor'];
			$sactual   = $row1['sactual'];
			$eliminado   = $row1['eliminado'];
			$car	   = 0;
			$sig       = "";
			if ($tipmov == 1)
			{
				$sig   = 'mas';
			}
			if ($tipmov == 2)
			{
				$sig   = 'menos';
			}
			if (($tipmov == 9) && ($tipdoc == 9) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 10) && ($tipdoc == 9) && ($eliminado == 0))
			{
				$sig   = 'mas';
			}
			if (($tipmov == 10) && ($tipdoc == 10) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 11) && ($tipdoc == 11) && ($eliminado == 0))
			{
				$sig   = 'mas';
			}
			if (($tipmov == 9) && ($tipdoc == 11) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
                          /////////desde aqui
                        
			if (($tipmov == 1) && ($tipdoc == 1) && ($eliminado == 0))
			{
				$sig   	 = 'mas';
			}
                        
                      
			if (($tipmov == 1) && ($tipdoc == 2) && ($eliminado == 0))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 1) && ($tipdoc == 2) && ($eliminado == 0))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 1) && ($tipdoc == 3) && ($eliminado == 0))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 1) && ($tipdoc == 4) && ($eliminado == 0))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 1) && ($tipdoc == 5) && ($eliminado == 0))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 2) && ($tipdoc == 1) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 2) && ($tipdoc == 2) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 2) && ($tipdoc == 3) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 2) && ($tipdoc == 4) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 2) && ($tipdoc == 5) && ($eliminado == 0))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 1) && ($tipdoc == 1) && ($eliminado == 1))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 1) && ($tipdoc == 5) && ($eliminado == 1))
			{
				$sig   	 = 'menos';
			}
			if (($tipmov == 1) && ($tipdoc == 1) && ($eliminado == 3))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 1) && ($tipdoc == 5) && ($eliminado == 3))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 2) && ($tipdoc == 1) && ($eliminado == 1))
			{
				$sig   	 = 'mas';
			}
			if (($tipmov == 2) && ($tipdoc == 3) && ($eliminado == 1))
			{
				$sig   	 = 'mas';
			}
                        
			if ($factor == 1)
			{
				if ($qtypro <> "")
				{
					$cant      = $qtypro;
					$descuenta = $cant * $factor;
					$car	   = $descuenta;
				}
				if ($fraccion <> "")
				{
					$cant      = convertir_a_numero($fraccion);
					$descuenta = $cant;
					$car	   = $descuenta;
				}
			}
			else
			{
				if ($qtypro <> "")
				{
					$cant      = $qtypro;
					$descuenta = $cant * $factor;
					$car	   = $descuenta;
				}
				if ($fraccion <> "")
				{
					$cant      = convertir_a_numero($fraccion);
					$descuenta = $cant;
					$car	   = $descuenta;
				}
			}
			if ($sig == 'mas')
			{
			$saldoactual = $car + $re;
			}
			else
			{
			$saldoactual = $re - $car;
			}
		}
		}
		mysqli_query($conexion,"UPDATE producto set $tabla = '$saldoactual' where codpro = '$codpro'");
}
}
$sql="select codpro from kardex where fecha >= '2019/06/19' and sucursal = '$local' and codpro = '$codpro' group by codpro order by codpro";
$result = mysqli_query($conexion,$sql);
if (mysqli_num_rows($result)){
while ($row = mysqli_fetch_array($result)){
	$codpro     = $row['codpro'];
	$stockpro   = 0;
	$s000		= 0;
	$s001		= 0;
	$s002		= 0;
	$s003		= 0;
	$s004		= 0;
	$s005		= 0;
	$s006		= 0;
	$s007		= 0;
	$s008		= 0;
	$s009		= 0;
	$s010		= 0;
	$s011		= 0;
	$s012		= 0;
	$s013		= 0;
	$s014		= 0;
	$s015		= 0;
	$s016		= 0;
	$sql1="SELECT s000,s001,s002,s003,s004,s005,s006,s007,s008,s009,s010,s011,s012,s013,s014,s015,s016 FROM producto where codpro = '$codpro'";
	$result1 = mysqli_query($conexion,$sql1);
	if (mysqli_num_rows($result1)){
	while ($row1 = mysqli_fetch_array($result1)){
	$s000 = 0;
	$s001 = 0;
	$s002 = 0;
	$s003 = 0;
	$s004 = 0;
	$s005 = 0;
	$s006 = 0;
	$s007 = 0;
	$s008 = 0;
	$s009 = 0;
	$s010 = 0;
	$s011 = 0;
	$s012 = 0;
	$s013 = 0;
	$s014 = 0;
	$s015 = 0;
	$s016 = 0;
		$s000    = $row1['s000'];
		$s001    = $row1['s001'];
		$s002    = $row1['s002'];
		$s003    = $row1['s003'];
		$s004    = $row1['s004'];
		$s005    = $row1['s005'];
		$s006    = $row1['s006'];
		$s007    = $row1['s007'];
		$s008    = $row1['s008'];
		$s009    = $row1['s009'];
		$s010    = $row1['s010'];
		$s011    = $row1['s011'];
		$s012    = $row1['s012'];
		$s013    = $row1['s013'];
		$s014    = $row1['s014'];
		$s015    = $row1['s015'];
		$s016    = $row1['s016'];
		$stockpro = $s000 + $s001 + $s002 + $s003 + $s004 + $s005 + $s006 + $s007 + $s008 + $s009 + $s010 + $s011 + $s012 + $s013 + $s014 + $s015 + $s016;
		mysqli_query($conexion,"UPDATE producto set stopro = '$stockpro' where codpro = '$codpro'");
	}}
}}
/*
$sql1="SELECT codpro,s000,s001,s002,s003,s004,s005,s006,s007,s008,s009,s010,s011,s012,s013,s014,s015,s016 FROM producto order by codpro";
$result1 = mysqli_query($conexion,$sql1);
if (mysqli_num_rows($result1)){
while ($row1 = mysqli_fetch_array($result1)){
	$stockpro = 0;
	$codpro  = $row1['codpro'];
	$s000    = $row1['s000'];
	$s001    = $row1['s001'];
	$s002    = $row1['s002'];
	$s003    = $row1['s003'];
	$s004    = $row1['s004'];
	$s005    = $row1['s005'];
	$s006    = $row1['s006'];
	$s007    = $row1['s007'];
	$s008    = $row1['s008'];
	$s009    = $row1['s009'];
	$s010    = $row1['s010'];
	$s011    = $row1['s011'];
	$s012    = $row1['s012'];
	$s013    = $row1['s013'];
	$s014    = $row1['s014'];
	$s015    = $row1['s015'];
	$s016    = $row1['s016'];
	$stockpro = $s000 + $s001 + $s002 + $s003 + $s004 + $s005 + $s006 + $s007 + $s008 + $s009 + $s010 + $s011 + $s012 + $s013 + $s014 + $s015 + $s016;
	mysqli_query($conexion,"UPDATE producto set stopro = '$stockpro' where codpro = '$codpro'");
}}
*/
header("Location: kardex1.php");
?>