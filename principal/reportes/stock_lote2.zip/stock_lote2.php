<?php include('../session_user.php');
require_once('../../conexion.php');
require_once('../../titulo_sist.php');
header("Content-Type: application/vnd.ms-excel");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("content-disposition: attachment;filename=SIST_EXPORT_DATA.xls");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $desemp?></title>
<link href="css/style1.css" rel="stylesheet" type="text/css" />

</head>
<?php require_once("../../funciones/functions.php");	//DESHABILITA TECLAS
require_once("../../funciones/funct_principal.php");	//IMPRIMIR-NUME
$sql="SELECT * FROM usuario where usecod = '$usuario'";
$result = mysqli_query($conexion,$sql);
if (mysqli_num_rows($result)){
while ($row = mysqli_fetch_array($result)){
	$user    = $row['nomusu'];
}
}
$hour   = date(G);
//$date	= CalculaFechaHora($hour);  
$date = date("Y-m-d");
//$hour   = CalculaHora($hour);
$min	= date(i);
if ($hour <= 12)
{
    $hor    = "am";
}
else
{
    $hor    = "pm";
}
$val    = $_REQUEST['val'];
$desc   = $_REQUEST['desc'];
$tipo   = $_REQUEST['tipo'];
$local  = $_REQUEST['local'];
if ($local <> 'all')
{
	$sql="SELECT nomloc FROM xcompa where codloc = '$local'";
	$result = mysqli_query($conexion,$sql);
	if (mysqli_num_rows($result)){
	while ($row = mysqli_fetch_array($result)){
		$nomloc    = $row['nomloc'];
	}
	}
	$conditionLocal = " and (ml.codloc='$local' or ml.codloc is null) ";

	if ($nomloc == "LOCAL0")
	{
		$columna = 's000';
	}
	if ($nomloc == "LOCAL1")
	{
		$columna = 's001';
	}
	if ($nomloc == "LOCAL2")
	{
		$columna = 's002';
	}
	if ($nomloc == "LOCAL3")
	{
		$columna = 's003';
	}
	if ($nomloc == "LOCAL4")
	{
		$columna = 's004';
	}
	if ($nomloc == "LOCAL5")
	{
		$columna = 's005';
	}
	if ($nomloc == "LOCAL6")
	{
		$columna = 's006';
	}
	if ($nomloc == "LOCAL7")
	{
		$columna = 's007';
	}
	if ($nomloc == "LOCAL8")
	{
		$columna = 's008';
	}
	if ($nomloc == "LOCAL9")
	{
		$columna = 's009';
	}
	if ($nomloc == "LOCAL10")
	{
		$columna = 's010';
	}
	if ($nomloc == "LOCAL11")
	{
		$columna = 's011';
	}
	if ($nomloc == "LOCAL12")
	{
		$columna = 's012';
	}
	if ($nomloc == "LOCAL13")
	{
		$columna = 's013';
	}
	if ($nomloc == "LOCAL14")
	{
		$columna = 's014';
	}
	if ($nomloc == "LOCAL15")
	{
		$columna = 's015';
	}
	if ($nomloc == "LOCAL16")
	{
		$columna = 's016';
	}
	if ($nomloc == "LOCAL17")
	{
		$columna = 's017';
	}
	if ($nomloc == "LOCAL18")
	{
		$columna = 's018';
	}
	if ($nomloc == "LOCAL19")
	{
		$columna = 's019';
	}
	if ($nomloc == "LOCAL20")
	{
		$columna = 's020';
	}

} else {
	$conditionLocal = "";
	
	$columna='p.s000 + p.s001 + p.s002 + p.s003 + p.s004 + p.s005 +
		p.s006 + p.s007 + p.s008 + p.s009 + p.s010 + p.s011 +
		p.s012 + p.s013 + p.s014 + p.s015 + p.s016 + p.s017 +
		p.s018 + p.s019 + p.s020 ';
}
if ($tipo == 1)
{
$desc_tipo = "PRODUCTO";
}
else
{
$desc_tipo = "MARCA";
}
?>
<body>
<table width="930" border="0" align="center">
  <tr>
    <td><table width="914" border="0">
      <tr>
        <td width="260"><strong><?php echo $desemp?></strong></td>
        <td width="380"><div align="center"><strong>REPORTE DE STOCK POR LOTES </strong></div></td>
        <td width="260"><div align="right"><strong>FECHA: <?php echo date('d/m/Y');?> - HORA : <?php echo $hour;?>:<?php echo $min;?> <?php echo $hor?></strong></div></td>
      </tr>

    </table>
      <table width="914" border="0">
        <tr>
          <td width="134"><strong>PAGINA # </strong></td>
          <td width="633"><div align="center"><b>REPORTE POR <?php echo $desc_tipo?> - <?php echo $desc?></b></div></td>
          <td width="133"><div align="right">USUARIO:<span class="text_combo_select"><?php echo $user?></span></div></td>
        </tr>
      </table>
      <div align="center"><img src="../../images/line2.png" width="910" height="4" /></div></td>
  </tr>
</table>
<table width="930" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="926" border="0" align="center">
      <tr>
        <td style='width:33px'><strong>N&ordm;</strong></td>
        <td style='width:100px'><div align="left"><strong>CÓDIGO </strong></div></td>
        <td style='width:400px'><div align="left"><strong>PRODUCTO </strong></div></td>
				<td style='width:200px'><div align="left"><strong>MARCA </strong></div></td>
				<td style='width:200px'><div align="left"><strong>PRÓXIMO VENC. </strong></div></td>
				<td style='width:100px'><div align="left"><strong>LOCAL </strong></div></td>
				<td style='width:100px'><div align="left"><strong>STOCK (ARCH. PRODUCTO) </strong></div></td>
				<td style='width:100px'><div align="left"><strong>STOCK (POR LOTE) </strong></div></td>
				<td style='width:80px'><div align="center"><strong>VER DETALLE </strong></div></td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="930" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
	<?php $c = 0;
		if ($tipo == 1)
		{
			$sql = "SELECT p.codpro, p.stopro, p.desprod, ml.codloc, xc.nomloc,
						tt.destab, MIN(date_format(str_to_date(concat('01/',ml.vencim),'%d/%m/%Y'),'%Y-%m-%d')) venc,
						$columna sttotal, sum(stock) stocklote
						from producto p left join movlote ml on ml.codpro=p.codpro 
						left join xcompa xc on xc.codloc=ml.codloc 
						inner join titultabladet tt on p.codmar = tt.codtab 
						where (date_format(str_to_date(concat('01/',ml.vencim),'%d/%m/%Y'),'%Y-%m-%d') >= NOW() 
						or ml.vencim is null) 
						and desprod like '$desc%'
						$conditionLocal
						group by p.codpro, p.stopro, p.desprod, tt.destab order by ml.vencim desc";
		}
		else
		{
			$sql = "SELECT p.codpro, p.stopro, p.desprod,  ml.codloc, xc.nomloc,
						tt.destab, MIN(date_format(str_to_date(concat('01/',ml.vencim),'%d/%m/%Y'),'%Y-%m-%d')) venc,
						$columna sttotal, sum(stock) stocklote
						from producto p left join movlote ml on ml.codpro=p.codpro 
						left join xcompa xc on xc.codloc=ml.codloc 
						inner join titultabladet tt on p.codmar = tt.codtab 
						where (date_format(str_to_date(concat('01/',ml.vencim),'%d/%m/%Y'),'%Y-%m-%d') >= NOW() 
						or ml.vencim is null) 
						and tiptab = 'M' and destab like '$desc%'
						$conditionLocal
						group by p.codpro, p.stopro, p.desprod, tt.destab order by ml.vencim desc";
		}
	$result = mysqli_query($conexion,$sql);
	if (mysqli_num_rows($result)){
	?>
	<table width="926" border="0" align="center">
      <?php while ($row = mysqli_fetch_array($result)){
		$codpro      = $row['codpro'];
		$producto    = $row['desprod'];
		$marca       = $row['destab'];
		$codloc       = $row['codloc'];
		$nomloc       = $row['nomloc'];
		$stocklote       = $row['stocklote'];
		$stopro        = $row['stopro'];
		$sttotal        = $row['sttotal'];
		$venc        = $row['venc'];
		$c++;
	  ?>
	  <tr>
		<td style='width:33px'><?php echo $c;?></td>
        <td style='width:100px'><?php echo $codpro;?></td>
        <td style='width:400px'><?php echo $producto;?></td>
		<td style='width:200px'><?php echo $marca;?></td>
		<td style='width:80px'><?php echo $venc;?></td>
		<td style='width:100px'><?php echo $nomloc;?></td>
		<td style='width:100px'><?php echo $sttotal;?></td>
		<td style='width:100px'><?php echo $stocklote;?></td>
		<td width="80"><center></center></td>
      </tr>
	  <?php }
	  ?>
    </table>
	<?php }
	?>
	</td>
  </tr>
</table>
</body>
</html>
